
'''
CONTAINS THE KEY AND SECRET KEY NEEDED TO RETRIEVE TOKEN
'''


spotify_client_id = 'b6d5a1e6f8f84849baf3492f831103ae'

spotify_client_secret_id = '81cd68d857f9437b9cf8218aaac7b884'